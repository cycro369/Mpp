# Build a Portfolio Website with HTML5 + CSS
### A Self-Paced, Step-by-Step Course Guide

---

## A Quick Note on How This Guide Is Organized

Your original topic list is all here, but it's been **re-sequenced into a logical teaching order** — theory before practice, and each build step before the one that depends on it. Two changes worth knowing about:

1. "Syntax, selectors, and types of CSS" was listed twice in your outline — it now appears **once**, right after the HTML-vs-CSS comparison, since selectors are needed before any hands-on styling.
2. The folder structure and `index.html` are created **before** the navbar/footer/form/media steps, since you can't build what you haven't got a place to put yet.

Everything you asked for is covered. Work through the modules in order — each one builds on the last.

---

## Learning Objectives

By the end of this guide, you will be able to:
- Explain what CSS is and how it relates to HTML5
- Write CSS using correct syntax and the right selector for the job
- Choose between inline, internal, and external CSS — and between local files and CDNs
- Structure a real project folder from scratch
- Build a working portfolio site with a nav bar (with dropdown), footer, form, hyperlinks, and embedded media
- Build an "Activities" page that lists and links to sub-pages
- Reuse a nav/footer **template** across multiple pages without retyping it

---

## Module 1 — What Is CSS, and How Does It Relate to HTML5?

**HTML5** (HyperText Markup Language) gives a web page its **structure and content** — headings, paragraphs, images, forms, links. It answers "what is on the page and what does it mean."

**CSS** (Cascading Style Sheets) gives that structure its **appearance** — colors, fonts, spacing, layout, animation. It answers "how does it look."

| | HTML5 | CSS |
|---|---|---|
| Job | Structure & meaning | Presentation & layout |
| Answers | "What is this?" | "How should it look?" |
| Example | `<h1>My Name</h1>` | `h1 { color: navy; }` |

**Why they're separated on purpose:** this is called *separation of concerns*. One HTML file can be restyled completely just by swapping the CSS file — no HTML editing needed. This is the entire reason CSS exists rather than styling attributes being baked into HTML tags.

**The "Cascading" part:** when multiple CSS rules could apply to the same element, CSS follows a predictable order of precedence (source order, specificity, and `!important`) to decide which one wins. You'll see this in action in Module 4.

---

## Module 2 — Logical Comparison: Building a House (HTML5 Alone) vs. HTML5 + CSS

Think of a website like a house under construction.

| Stage | HTML5 Alone | HTML5 + CSS |
|---|---|---|
| Walls, rooms, doors | ✅ Built (structure exists) | ✅ Built |
| Paint, flooring, furniture | ❌ None — bare concrete | ✅ Styled and arranged |
| Room layout (where things sit) | Default stacking only, top to bottom | ✅ Controlled with layout tools (Flexbox, Grid) |
| Visitor's first impression | Functional but unfinished | Polished and intentional |
| Can you still walk through it? | Yes | Yes — it's easier and more pleasant |

**In practice:** an HTML-only page renders as black text on a white background, stacked top to bottom, with default browser fonts and spacing. It works — links click, forms submit — but it looks like a plain document, not a house you'd want to live in. CSS is the interior design pass that makes the structure usable and presentable.

---

## Module 3 — CSS Syntax, Selectors, and Types

### 3.1 Basic Syntax

```css
selector {
  property: value;
  property: value;
}
```

- **Selector** — which HTML element(s) this rule targets
- **Property** — the visual trait being changed (`color`, `font-size`, `margin`…)
- **Value** — the setting for that property
- Every declaration ends in a semicolon `;`; the whole block sits inside curly braces `{ }`

```css
p {
  color: #333333;
  font-size: 16px;
}
```
*Note: this targets every `<p>` element on the page.*

### 3.2 Types of Selectors

| Selector | Syntax | Targets | Example |
|---|---|---|---|
| Universal | `*` | Every element | `* { margin: 0; }` |
| Type/Element | `tagname` | All elements of that tag | `p { }` |
| Class | `.classname` | Any element with that class | `.card { }` |
| ID | `#idname` | The one element with that ID | `#main-nav { }` |
| Attribute | `[attr="value"]` | Elements with a matching attribute | `input[type="text"] { }` |
| Descendant | `A B` | B nested anywhere inside A | `nav ul { }` |
| Child | `A > B` | B that is a *direct* child of A | `nav > ul { }` |
| Pseudo-class | `:state` | Element in a particular state | `a:hover { }` |
| Pseudo-element | `::part` | A specific part of an element | `p::first-letter { }` |

**Note on Class vs. ID:** a class (`.`) can be reused on many elements; an ID (`#`) must be unique per page and is meant for one specific element (like the nav bar). IDs also carry higher specificity — they win over classes when rules conflict.

### 3.3 The Three Ways to Apply CSS ("Types" of CSS)

**1. Inline CSS** — written directly on the HTML tag using the `style` attribute:
```html
<p style="color: red;">This text is red.</p>
```

**2. Internal (Embedded) CSS** — written inside a `<style>` tag in the `<head>` of the HTML file:
```html
<head>
  <style>
    p { color: red; }
  </style>
</head>
```

**3. External CSS** — written in a separate `.css` file and linked in with `<link>`:
```html
<head>
  <link rel="stylesheet" href="Styles/style.css">
</head>
```

We compare these properly next, because the choice matters for every project you build.

---

## Module 4 — Inline CSS vs. External CSS

| | Inline CSS | External CSS |
|---|---|---|
| Where it lives | Inside the HTML tag itself | Separate `.css` file |
| Reusability | None — must repeat on every tag | One rule styles the whole site |
| Cascade priority | Highest (overrides internal & external) | Normal cascade rules apply |
| Maintainability | Poor — hard to update at scale | Excellent — edit once, applies everywhere |
| Caching | Not cached (part of HTML) | Cached by the browser — faster repeat loads |
| Best use case | One-off, quick test, or JS-driven dynamic style | Real websites, including this portfolio project |

**Rule of thumb for this course:** you will use **external CSS** for the whole portfolio site (`Styles/style.css`). Inline CSS is shown above only so you can recognize it — it's rarely the right tool for a real project because it defeats the "separation of concerns" idea from Module 1.

---

## Module 5 — Local CSS vs. CDN (Important Distinction)

This is a *different* question from inline-vs-external. It's about **where your external CSS file physically comes from**.

**Local CSS** — a `.css` file that lives inside your own project folder:
```html
<link rel="stylesheet" href="Styles/style.css">
```

**CDN (Content Delivery Network) CSS** — a `.css` file hosted on someone else's server (used to load frameworks like Bootstrap):
```html
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
```

| | Local CSS | CDN CSS |
|---|---|---|
| Works offline | ✅ Yes | ❌ No — needs internet |
| Load speed (first visit) | Fast for small files | Can be faster for large frameworks (often already cached from other sites) |
| Full control over the code | ✅ You own every line | ❌ You depend on the provider's file staying online and unchanged |
| Good for learning fundamentals | ✅ Yes — you write and see every rule | ❌ Hides the mechanics |
| Good for production speed on big frameworks | Possible, but you host the whole library yourself | ✅ Often optimized and pre-cached across sites |
| Risk if provider goes down | None | Site loses all styling until it's back |

**Guidance for this project:** write your **own CSS locally** in `Styles/style.css`. That's non-negotiable for the learning goal — it's how you actually learn selectors and the box model. CDNs are useful later, once you're pulling in a full framework you don't want to hand-copy (see Module 6). Never mix "I don't understand this rule" with "I got it from a CDN" — know what every line in your own stylesheet does.

---

## Module 6 — CSS Frameworks: Side-by-Side Comparison

A **CSS framework** is a pre-written, pre-tested CSS file (usually loaded via CDN) that gives you ready-made classes for buttons, grids, cards, etc., so you don't write every rule by hand.

Same button, three ways:

**Plain CSS (what you're learning in this course)**
```html
<style> .btn { background: #2c3e50; color: white; padding: 10px 20px; border-radius: 4px; border: none; } </style>
<button class="btn">Click Me</button>
```
*Output: a dark navy button with white text — exact appearance fully controlled by you.*

**Bootstrap (CDN framework)**
```html
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
<button class="btn btn-primary">Click Me</button>
```
*Output: a blue rounded button — Bootstrap's default theme — using pre-built classes instead of custom rules.*

**Tailwind CSS (CDN, utility-class framework)**
```html
<script src="https://cdn.tailwindcss.com"></script>
<button class="bg-slate-800 text-white px-5 py-2 rounded">Click Me</button>
```
*Output: similar dark button, but styled entirely through combined utility classes rather than a `.btn` rule.*

| Framework | Approach | Learning curve | When to reach for it |
|---|---|---|---|
| Plain CSS | You write every rule | Steepest, but foundational | Learning, small/custom projects (this course) |
| Bootstrap | Pre-built components (`.btn`, `.card`, `.navbar`) | Easy | Fast prototypes, admin dashboards |
| Tailwind | Utility classes composed in the HTML | Moderate | Highly custom designs, larger apps |

**For this course:** finish the whole portfolio in plain, hand-written CSS first. Frameworks are worth exploring afterward, once you understand *why* the button looks the way it does.

---

## Module 7 — Planning the Project: Folder Structure

Before touching code, set up the project skeleton. This keeps assets, styles, and content pages from becoming a tangled mess as the site grows.

```
MyPortfolio/
│
├── index.html          ← the landing page (see Module 9)
│
├── Assets/              ← images, videos, icons, downloadable files
│   ├── images/
│   └── media/
│
├── Styles/               ← all CSS lives here
│   └── style.css
│
└── Activities/           ← one HTML file per activity/project
    ├── Activity1.html
    ├── Activity2.html
    └── Activity3.html
```

**Notes on each folder:**
- **Assets** — anything that isn't code: photos, logos, downloadable PDFs, video/audio files.
- **Styles** — every `.css` file for the site. Keeping this separate from HTML reinforces the separation-of-concerns idea from Module 1.
- **Activities** — one `.html` file *per* activity/project you want to showcase. The **file name matters**: it must match the link text used in the Activities table (Module 17), e.g., an activity called "Photography" lives at `Activities/Photography.html`.

---

## Module 8 — Step 1: Create the Project Folder

1. On your computer, create a folder named exactly `MyPortfolio`.
2. Inside it, create three subfolders: `Assets`, `Styles`, `Activities`.
3. Inside `Assets`, optionally create `images` and `media` subfolders to stay organized.

*Note: folder and file names are case-sensitive on many web servers (and on Mac/Linux). Keep a consistent naming habit — this guide uses PascalCase for folders (`MyPortfolio`, `Activities`) and lowercase for files (`index.html`, `style.css`) to avoid broken links later.*

---

## Module 9 — Step 2: Create `index.html` (the Landing Page)

Create a file named **`index.html`** directly inside `MyPortfolio/`.

> **Why `index.html` and not `home.html`?**
> Every web server has a concept of a "default document" — the file it automatically loads when someone visits a folder URL without specifying a file name (e.g., visiting `yoursite.com/` instead of `yoursite.com/home.html`). Across virtually every web server (Apache, Nginx, GitHub Pages, etc.), that default file name is `index.html` by convention. Name your landing page anything else, and visitors get a folder listing or a 404 error instead of your site. **Always name your homepage `index.html`.**

Base HTML5 boilerplate:

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>My Portfolio</title>
  <link rel="stylesheet" href="Styles/style.css">
</head>
<body>

  <!-- Nav bar, footer, and page content go here -->

</body>
</html>
```

**Notes on each line:**
- `<!DOCTYPE html>` — tells the browser this is an HTML5 document; must be the very first line.
- `<html lang="en">` — the root element; `lang` helps screen readers and search engines.
- `<meta charset="UTF-8">` — sets text encoding so special characters (like `©` later) render correctly.
- `<meta name="viewport"...>` — makes the page render properly on mobile devices; without it, mobile browsers zoom out to show a "desktop" view.
- `<title>` — text shown in the browser tab.
- `<link rel="stylesheet" href="...">` — connects your **local** external CSS file (Module 5) to this page.

---

## Module 10 — Step 3: Build the Navigation Bar (with Dropdown)

Add this inside `<body>`, above your main content:

```html
<nav class="navbar">
  <ul class="nav-list">
    <li><a href="index.html">Home</a></li>
    <li class="dropdown">
      <a href="#">More ▾</a>
      <ul class="dropdown-menu">
        <li><a href="Activities/activities.html">Activities</a></li>
        <li><a href="about.html">About Me</a></li>
        <li><a href="contact.html">Contact</a></li>
      </ul>
    </li>
  </ul>
</nav>
```

**Notes on each element:**
- `<nav>` — a semantic HTML5 tag specifically for navigation blocks (helps accessibility tools and SEO recognize it as site navigation).
- `<ul>` / `<li>` — an unordered list is the standard way to build nav items; each link is a list item.
- `<a href="index.html">` — a hyperlink back to the homepage (Module 14 covers hyperlinks in depth).
- `.dropdown` / `.dropdown-menu` — these classes are hooks for CSS, not built-in browser behavior. The dropdown itself is created entirely with CSS (next module) using the `:hover` pseudo-class from Module 3.

CSS to make it a working dropdown (add to `style.css`):

```css
.navbar { background: #2c3e50; }
.nav-list { display: flex; list-style: none; margin: 0; padding: 0; }
.nav-list > li { position: relative; }
.nav-list a { display: block; padding: 15px 20px; color: white; text-decoration: none; }
.nav-list a:hover { background: #34495e; }

.dropdown-menu {
  display: none;
  position: absolute;
  top: 100%;
  left: 0;
  background: #34495e;
  list-style: none;
  margin: 0;
  padding: 0;
  min-width: 160px;
}
.dropdown:hover .dropdown-menu { display: block; }
```

**Notes:**
- `display: flex` on `.nav-list` lines the menu items up horizontally instead of the default vertical list stacking.
- `.dropdown-menu { display: none; }` hides the submenu by default.
- `.dropdown:hover .dropdown-menu { display: block; }` uses a **descendant selector** combined with `:hover` (both from Module 3) — when the mouse hovers over `.dropdown`, its nested `.dropdown-menu` becomes visible. No JavaScript required.

---

## Module 11 — Step 4: Build the Footer

Add this just before the closing `</body>` tag:

```html
<footer class="site-footer">
  <p>&copy; 2026 Your Name. All Rights Reserved.</p>
</footer>
```

```css
.site-footer {
  text-align: center;
  padding: 20px;
  background: #2c3e50;
  color: white;
}
```

**Notes:**
- `<footer>` — semantic HTML5 tag for footer content.
- `&copy;` — an HTML **character entity** that renders the © symbol (typing © directly usually also works now that files are UTF-8, but the entity is the traditional, always-safe method).
- `text-align: center` — centers the inline content (the `<p>` text) inside the footer block.
- *Optional upgrade:* replace the hardcoded year with JavaScript so it always stays current: `<span id="year"></span>` + `document.getElementById('year').textContent = new Date().getFullYear();`. Not required for this course, but worth knowing exists.

---

## Module 12 — Step 5: The Main Content Area (`<div>` as a Container)

Between the nav bar and footer, wrap your page-specific content in a `<div>`:

```html
<div id="main-content">
  <h1>Welcome to My Portfolio</h1>
  <p>This is where the content of each page will live.</p>
</div>
```

**Notes:**
- `<div>` — a generic block-level **container** with no built-in meaning; it exists purely to group content so CSS/JS can target it.
- `id="main-content"` — this specific ID is important: it's the **one part of the page that will change** between pages, while nav and footer stay identical. This is the anchor for the templating approach in Module 19.

---

## Module 13 — Step 6: Adding a Contact Form

Create `contact.html` (same nav/footer as `index.html`, different `#main-content`):

```html
<div id="main-content">
  <h1>Contact Me</h1>
  <form action="#" method="post">
    <label for="name">Name:</label>
    <input type="text" id="name" name="name" required>

    <label for="email">Email:</label>
    <input type="email" id="email" name="email" required>

    <label for="message">Message:</label>
    <textarea id="message" name="message" rows="5" required></textarea>

    <button type="submit">Send</button>
  </form>
</div>
```

**Notes on each element:**
- `<form action="#" method="post">` — `action` is where the data is sent (a real project points this to a server script; `#` is a placeholder for now); `method="post"` sends form data in the request body rather than the URL.
- `<label for="name">` — clicking the label focuses the matching input (linked via `id`); important for accessibility.
- `<input type="text">` / `type="email"` — the `type` attribute changes both behavior and keyboard (mobile devices show an `@`-friendly keyboard for `email`).
- `required` — a built-in HTML5 validation attribute; the browser blocks submission until the field is filled.
- `<textarea>` — a multi-line text input; `rows` sets its visible height.
- `<button type="submit">` — submits the form.

---

## Module 14 — Step 7: Hyperlinks

The `<a>` (anchor) tag is how every link on your site works — nav links, footer links, activity links.

```html
<!-- Relative link (inside the project) -->
<a href="Activities/activities.html">See My Activities</a>

<!-- Absolute link (outside the project) -->
<a href="https://github.com/yourusername" target="_blank">My GitHub</a>
```

**Notes:**
- `href` — the destination; a **relative path** (`Activities/activities.html`) points to a file inside your own project folder, while an **absolute path** (`https://...`) points to an external site.
- `target="_blank"` — opens the link in a new tab; typically used for external links so the visitor doesn't lose your site.
- Relative paths must match your actual folder structure exactly (Module 7) — a mismatch is the #1 cause of broken links in student projects.

---

## Module 15 — Step 8: Embedding Media

```html
<!-- Image -->
<img src="Assets/images/profile.jpg" alt="Portrait photo of Your Name" width="300">

<!-- Video -->
<video controls width="500">
  <source src="Assets/media/demo-reel.mp4" type="video/mp4">
  Your browser does not support the video tag.
</video>

<!-- Audio -->
<audio controls>
  <source src="Assets/media/intro.mp3" type="audio/mpeg">
</audio>

<!-- Embedded external content (e.g. a map or YouTube video) -->
<iframe src="https://www.youtube.com/embed/VIDEO_ID" width="560" height="315" allowfullscreen></iframe>
```

**Notes on each tag:**
- `<img>` — `src` is the file path; `alt` is required accessibility text describing the image (also shown if the image fails to load).
- `<video>` / `<audio>` — `controls` shows the play/pause/volume UI; the `<source>` child tag lets you specify the file and its MIME `type`; the plain text inside is a fallback for unsupported browsers.
- `<iframe>` — embeds another web page inside yours (commonly used for YouTube videos or maps); `allowfullscreen` permits full-screen playback.

---

## Module 16 — Putting It Together: `style.css`

A consolidated stylesheet covering everything built so far:

```css
/* Reset & base */
* { margin: 0; padding: 0; box-sizing: border-box; }
body { font-family: Arial, sans-serif; line-height: 1.6; color: #222; }

/* Nav bar (Module 10) */
.navbar { background: #2c3e50; }
.nav-list { display: flex; list-style: none; }
.nav-list a { display: block; padding: 15px 20px; color: white; text-decoration: none; }
.nav-list a:hover { background: #34495e; }
.dropdown { position: relative; }
.dropdown-menu { display: none; position: absolute; background: #34495e; list-style: none; min-width: 160px; }
.dropdown:hover .dropdown-menu { display: block; }

/* Main content (Module 12) */
#main-content { max-width: 900px; margin: 40px auto; padding: 0 20px; }

/* Form (Module 13) */
form { display: flex; flex-direction: column; max-width: 400px; }
form label { margin-top: 12px; font-weight: bold; }
form input, form textarea { padding: 8px; margin-top: 4px; border: 1px solid #ccc; border-radius: 4px; }
form button { margin-top: 16px; padding: 10px; background: #2c3e50; color: white; border: none; border-radius: 4px; cursor: pointer; }

/* Activities table (Module 17) */
table { width: 100%; border-collapse: collapse; margin-top: 20px; }
th, td { border: 1px solid #ddd; padding: 12px; text-align: left; }
th { background: #f4f4f4; }

/* Footer (Module 11) */
.site-footer { text-align: center; padding: 20px; background: #2c3e50; color: white; margin-top: 40px; }
```

**Note:** `box-sizing: border-box` in the reset makes padding/border count *inside* an element's declared width rather than adding to it — this avoids a very common layout bug for beginners where boxes grow larger than expected.

---

## Module 17 — Step 9: The Activities Page (Two-Column Table of Links)

Create `Activities/activities.html`. When a visitor clicks **More → Activities** in the nav dropdown, this page loads and lists every activity as a linked row.

```html
<div id="main-content">
  <h1>My Activities</h1>
  <table>
    <thead>
      <tr>
        <th>Activity</th>
        <th>Description</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td><a href="Activity1.html">Photography</a></td>
        <td>A collection of my landscape and portrait work.</td>
      </tr>
      <tr>
        <td><a href="Activity2.html">Web Design</a></td>
        <td>Mockups and small sites I've built for practice.</td>
      </tr>
      <tr>
        <td><a href="Activity3.html">Volunteering</a></td>
        <td>Community projects I've taken part in.</td>
      </tr>
    </tbody>
  </table>
</div>
```

**Notes:**
- `<table>` / `<thead>` / `<tbody>` — the standard structure for tabular data: header row(s) separate from body rows.
- `<tr>` = table row, `<th>` = header cell, `<td>` = data cell.
- **Naming rule:** the file each link points to (`Activity1.html`) must sit inside the same `Activities/` folder and, ideally, match the activity's name for clarity — this guide uses `Activity1.html` for "Photography" as an example; feel free to rename it `Photography.html` for even easier maintenance. Whatever name you choose, **the link's `href` and the actual file name must match exactly**, including capitalization.
- *Why this is manual:* plain HTML/CSS cannot read a folder's contents automatically — there's no server-side code here. Each new activity means adding one table row **and** creating the matching file by hand. (A future upgrade path — JavaScript `fetch()` calls or a backend language — could generate this list automatically, but that's beyond this course's scope.)

---

## Module 18 — Step 10: Individual Activity Pages

Each linked file (e.g., `Activities/Activity1.html`) is a full HTML page using the **same nav and footer**, with its own content in `#main-content`:

```html
<div id="main-content">
  <h1>Photography</h1>
  <img src="../Assets/images/photo1.jpg" alt="Sample photography work" width="400">
  <p>A description of this activity goes here.</p>
  <a href="activities.html">&larr; Back to Activities</a>
</div>
```

**Note:** because this file lives *inside* `Activities/`, its path back up to `Assets/` needs `../` (meaning "go up one folder level") — this is a common relative-path gotcha once you nest folders. The link back to the activities list uses no `../` because `activities.html` is a sibling file in the same folder.

---

## Module 19 — Template-Based HTML: Keeping Nav & Footer Consistent

You now have several pages (`index.html`, `contact.html`, `activities.html`, `Activity1.html`…) that all share the identical nav bar and footer, with only `#main-content` changing. That repeated, unchanging shell is your **template**.

**The manual template method (what this course uses):**

1. Build the nav bar and footer once, exactly as shown in Modules 10–11.
2. Copy that exact markup into every new HTML page you create.
3. Only ever edit the content **inside** `<div id="main-content">...</div>` per page.
4. If you need to change the nav or footer (e.g., add a new page link), update it in **every file** — tedious at this scale, but this repetition is exactly what teaches you why templating systems exist.

**Why this matters as a concept:** every real website — no matter how it's built — follows this same "shared shell, changing content" idea. What differs is *how* the shell gets reused:

| Approach | How it avoids retyping the shell | Typical use |
|---|---|---|
| Manual copy-paste (this course) | It doesn't — you copy it each time | Learning, tiny sites |
| Server-Side Includes (SSI) | Server pastes a shared `.html` snippet into each page at request time | Basic Apache-hosted sites |
| Template languages (PHP, EJS, Jinja) | A shared template file wraps changing content automatically | Dynamic/backend-driven sites |
| JavaScript `fetch()` includes | Browser loads nav/footer HTML into the page after load | Static sites wanting some reuse |
| Static site generators (11ty, Jekyll, Hugo) | Build tool compiles shared layout + content into full pages before upload | Larger static portfolios/blogs |

For this course, **stick with manual copy-paste**. Once you're comfortable, revisiting this table is your roadmap for "leveling up" the exact same MyPortfolio project.

---

## Module 20 — Final Project Checklist

Before considering the portfolio "done," confirm:

- [ ] `MyPortfolio/` folder contains `Assets/`, `Styles/`, `Activities/`, and `index.html`
- [ ] `index.html` is the landing page — no `home.html` in sight
- [ ] Nav bar present on every page, with a working `More` dropdown (Activities, About Me, Contact)
- [ ] Footer present on every page — centered, showing name + year + `&copy;`
- [ ] `#main-content` div holds page-specific content only
- [ ] At least one working `<form>` with labeled inputs
- [ ] Hyperlinks use correct relative paths (test every link by clicking it)
- [ ] At least one embedded media element (image, video, audio, or iframe)
- [ ] `activities.html` shows a two-column table linking to real files in `Activities/`
- [ ] Every activity's file name matches its table link exactly
- [ ] All CSS lives in `Styles/style.css` — no framework CDN used yet
- [ ] You can explain, in your own words, the difference between a class selector and an ID selector

---

## Module 21 — Suggested Next Steps

Once the checklist above is complete, natural directions to explore:
- Try rebuilding one page's styling using Bootstrap or Tailwind via CDN (Module 6), and compare the amount of CSS you had to write yourself.
- Learn CSS Flexbox and Grid in more depth for more advanced layouts than the nav bar's simple `display: flex`.
- Look into one templating approach from the Module 19 table — JavaScript `fetch()` includes are the easiest first step since they need no server setup.
- Add basic responsive design with `@media` queries so the site adapts to phone screens.

---

*This guide is intended for self-paced learning. Work through each module in order, build the project alongside it, and use the checklist in Module 20 to confirm your understanding before moving on.*
